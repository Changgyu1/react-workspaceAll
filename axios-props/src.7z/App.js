import logo from "./logo.svg";
import "./App.css";
import TimeOut from "./TimeOut";
import MovieListPaging from "./MovieListPaging";

function App() {
  return (
    <div className="App">
      <MovieListPaging />
    </div>
  );
}

export default App;
