import React from 'react';

function Footer(){
    return (
        <footer>
            <p>&copy; 2023 My website. All rights reserved.</p>
            <p><a href="https://github.com/Changgyu1">gitURL</a></p>
        </footer>
    )
}
export default Footer;