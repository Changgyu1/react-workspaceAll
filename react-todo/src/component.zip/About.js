import React from 'react';
import 해친놈 from '../img/안들린다.jpg';

function About (){
    
    return(
        <div>
            <h2>해친놈</h2>
            <img src={해친놈}/>
        </div>
    )
}
export default About;